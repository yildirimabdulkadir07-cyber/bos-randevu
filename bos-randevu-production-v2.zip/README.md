# Boş Randevu — v1.1

Son dakika boş randevuları müşterilerle buluşturan çalışan web/PWA + API MVP.

## Hızlı başlatma

Node.js 22+ gerekir.

```bash
npm install
node server.js
```

Sonra: http://localhost:3000

## Docker

```bash
docker compose up --build -d
```

## Demo hesaplar

İşletme: `isletme@bosrandevu.local` / `Isletme123!`

Admin: `admin@bosrandevu.local` / `Admin123!`

## Ürün durumu

Çalışan: kullanıcı kaydı/giriş, oturum, boş slot arama, rezervasyon, yarış koşuluna karşı atomik slot kilitleme, iptal, favoriler, demo ödeme, puanlama/yorum, işletme hizmet yönetimi, fırsat yayınlama, işletme paneli, admin istatistikleri, SQLite kalıcılığı ve mobil uyumlu PWA kabuğu.

Müşteri, işletme ve platform yöneticisi aynı API'ye rol bazlı yetkiyle bağlanır. Demo ödeme akışı gerçek para çekmez; canlı ödeme için sağlayıcı hesabı ve anahtarları gerekir.

Üretimden önce yapılması gerekenler: gerçek domain/HTTPS, PostgreSQL veya yönetilen DB, e-posta/SMS/push sağlayıcısı, iyzico/PayTR/Stripe gibi ödeme sağlayıcısı entegrasyonu, KVKK/çerez metinlerinin hukukçu tarafından gözden geçirilmesi, Apple/Google mağaza hesapları ve mobil paketleme.

## Not

Demo şifrelerini ve SQLite'ı üretimde değiştirmeden kullanmayın.

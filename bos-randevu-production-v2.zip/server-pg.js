// Compatible with the existing Render start command.
import {createApp} from './server.js';
if(!process.env.DATABASE_URL) throw Error('DATABASE_URL gerekli');
const app=await createApp({...process.env,LEGACY_MIGRATION:'true'});
app.server.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('SonŞans ready'));
for(const event of ['SIGTERM','SIGINT']) process.on(event,()=>app.close().then(()=>process.exit(0)));

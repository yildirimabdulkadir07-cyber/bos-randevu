# Boş Randevu Mobil 1.2

Bu paket Android ve iPhone için Capacitor tabanlı yerel projeleri içerir.

## Telefonda çalışan canlı sürüm

Mobil uygulama `https://bos-randevu-api.onrender.com` adresindeki canlı API'ye
bağlanır. Kayıt, giriş, randevu ve favori verileri Render PostgreSQL
veritabanında ortak ve kalıcı olarak tutulur.

## Android

1. Node.js 22+, Android Studio ve Android SDK kurun.
2. Proje klasöründe `npm install` ve `npm run mobile:sync` çalıştırın.
3. `npm run android` ile Android Studio'yu açın.
4. Build > Build APK(s) menüsünü kullanın.

Google Play için imzalı AAB dosyası, size ait yükleme anahtarıyla üretilmelidir.

## iPhone

1. macOS üzerinde Xcode kurun.
2. Proje klasöründe `npm install` ve `npm run mobile:sync` çalıştırın.
3. `npm run ios` ile Xcode projesini açın.
4. Signing & Capabilities bölümünde Apple Developer takımınızı seçin.
5. Archive işlemiyle IPA veya App Store paketi üretin.

## Mağaza yayını

Gerçek ödeme ve bildirim için sağlayıcı hesapları gerekir. App Store yüklemesi
Apple Developer üyeliği ve uygulama sahibinin Apple imzasıyla yapılmalıdır.

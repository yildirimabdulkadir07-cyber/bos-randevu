import fs from 'node:fs';
const origin=process.env.SONSANS_URL;
if(!origin)throw Error('Set SONSANS_URL to the verified HTTPS service URL before syncing a native build.');
const url=new URL(origin);if(url.protocol!=='https:'||url.username||url.password)throw Error('A public HTTPS URL without credentials is required.');
const file=new URL('../capacitor.config.json',import.meta.url);const config=JSON.parse(fs.readFileSync(file));config.appName='SonŞans';config.server={url:url.origin,cleartext:false,allowNavigation:[url.hostname]};fs.writeFileSync(file,JSON.stringify(config,null,2)+'\n');console.log('Native configuration ready for '+url.origin);

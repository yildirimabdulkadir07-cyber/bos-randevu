package com.bosrandevu.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
